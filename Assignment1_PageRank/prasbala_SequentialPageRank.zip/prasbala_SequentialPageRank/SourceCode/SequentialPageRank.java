
import java.io.*;
import java.util.*;

public class SequentialPageRank {
    // adjacency matrix read from file
    private HashMap<Integer, ArrayList<Integer>> adjMatrix = new HashMap<Integer, ArrayList<Integer>>();
    // input file name
    private String inputFile = "";
    // output file name
    private String outputFile = "";
    // number of iterations
    private int iterations = 10;
    // damping factor
    private double df = 0.85;
    // number of URLs
    private int size = 0;
    // calculating rank values
    private HashMap<Integer, Double> rankValues = new HashMap<Integer, Double>();

    /**
     * Parse the command line arguments and update the instance variables. Command line arguments are of the form
     * <input_file_name> <output_file_name> <num_iters> <damp_factor>
     *
     * @param args arguments
     */
    public void parseArgs(String[] args) {

        this.inputFile = args[0];
        this.outputFile = args[1];
        this.iterations = Integer.parseInt(args[2]);
        this.df = Double.parseDouble(args[3]);

    }

    /**
     * Read the input from the file and populate the adjacency matrix
     *
     * The input is of type
     *
     0
     1 2
     2 1
     3 0 1
     4 1 3 5
     5 1 4
     6 1 4
     7 1 4
     8 1 4
     9 4
     10 4
     * The first value in each line is a URL. Each value after the first value is the URLs referred by the first URL.
     * For example the page represented by the 0 URL doesn't refer any other URL. Page
     * represented by 1 refer the URL 2.
     *
     * @throws java.io.IOException if an error occurs
     */
    public void loadInput() throws IOException {
        
        FileReader read = new FileReader(new File(this.inputFile));
        BufferedReader buffRead = new BufferedReader(read);
        String ln;
        this.adjMatrix = new HashMap<>();
        while((ln = buffRead.readLine())!=null){
            Scanner nodes = new Scanner(ln);
            ArrayList<Integer> ref = new ArrayList<>();
            // pull out the first node to form the hashMap key
            int node = nodes.nextInt();
            // pull out the subsequent nodes to form the hashMap values
            while(nodes.hasNextInt()){
                ref.add(nodes.nextInt());
            }
            adjMatrix.put(node,ref);
            nodes.close();
        }
        read.close();
    }

    /**
     * Do fixed number of iterations and calculate the page rank values. You may keep the
     * intermediate page rank values in a hash table.
     */
    public void calculatePageRank() {

        float numOfUrls;
        numOfUrls = Collections.max(this.adjMatrix.keySet());
        Double initializePageRank = (double) (1 / (numOfUrls+1));
        for (Integer key : adjMatrix.keySet()){
            this.rankValues.put(key,initializePageRank);
            if(adjMatrix.get(key).size()==0){
                ArrayList<Integer> list = new ArrayList<>();
                for(int i=0;i<numOfUrls;i++){
                	if (i==key){
                        continue;
                    }
                    else{
                        list.add(i);
                    }
                }
                adjMatrix.put(key,list);
            }
        }

        for(int itrs = 1; itrs <= this.iterations; itrs++){
            for (int page=0; page<=numOfUrls; page++){
                Double dampFact = ((1-this.df)/numOfUrls);
                Double intPageRank = 0.0;
                for(Integer key : adjMatrix.keySet()){
                    if(adjMatrix.get(key).contains(page)) {
                        intPageRank += (this.rankValues.get(key) / this.adjMatrix.get(key).size());
                    }
                }
                intPageRank = dampFact + (this.df * intPageRank);
                this.rankValues.put(page,intPageRank);
            }
        }
        try{
        PrintWriter writer = new PrintWriter(this.outputFile);
        for (int page=0; page<=numOfUrls; page++){
        	writer.println(page+ "\t" + this.rankValues.get(page));
        }
        writer.close();
        }
        catch (IOException ex) {
           System.out.println("File Error");
        }
    }

    /**
     * Print the pagerank values. Before printing you should sort them according to decreasing order.
     * Print all the values to the output file. Print only the first 10 values to console.
     *
     * @throws IOException if an error occurs
     */
    public void printValues() throws IOException {
        List <Double> listPR = new ArrayList<Double>(this.rankValues.values());
        Collections.sort(listPR);
        Collections.reverse(listPR);
        listPR = listPR.subList(0, 10);
        System.out.println("Number of Iterations : "+this.iterations);
        for(Double key: listPR){
        	for (Map.Entry<Integer, Double> e : rankValues.entrySet()) {
        	    if(e.getValue()==key){
        	        System.out.println("Page:" + e.getKey() + "\t\t" + "PageRank:"+key);
        	    }
        	}
        }

    }

    public static void main(String[] args) throws IOException {
        SequentialPageRank sequentialPR = new SequentialPageRank();

        sequentialPR.parseArgs(args);
        sequentialPR.loadInput();
        sequentialPR.calculatePageRank();
        sequentialPR.printValues();
    }
}
